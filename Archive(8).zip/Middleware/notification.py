import boto3
import json


def publish_it(msg):

    client = boto3.client('sns', 'us-east-2', aws_access_key_id="AKIAJTVRMYB3QANDAPPA",
                          aws_secret_access_key="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")
    response = client.publish(TopicArn="arn:aws:sns:us-east-2:712020361988:CustomerChange",
                              Message=msg)
    return response


# email = 'gr2625@columbia.edu'
# publish_it(email)