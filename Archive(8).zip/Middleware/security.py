import jwt
from Context.Context import Context
from time import time
from flask import Response

from ast import literal_eval

_context = Context.get_default_context()
_secret = _context.get_context("JWT_SECRET")

def hash_password(pwd):
    global _context
    h = jwt.encode(pwd, key=_context.get_context("JWT_SECRET"))
    h = str(h)
    return h


def generate_token(info: dict, key=None) -> str:
    info["timestamp"] = time()
    email = info['email']

    admins = {"gr2625@columbia.edu"}
    if email in admins:
        info['role'] = 'admin'
    else:
        info['role'] = 'user'

    # info['created'] = str(info['created'])
    if not key:
        key = _context.get_context("JWT_SECRET")

    h = jwt.encode(info, key=key)
    h = str(h)

    return h


def decode_token(token: str, key=None) -> dict:
    if not token:
        raise ValueError("Token must be non empty")
    if not key:
        key = _context.get_context("JWT_SECRET")

    token = literal_eval(token)
    decoded = jwt.decode(token, key=key)
    return decoded


def authorize(request, token):
    # return None means it's authorized, Non-None means further function calls are interrupted
    method = request.method
    args = request.args
    path = request.path

    if path == "/api/login":
        return None

    if path == "/api/registration" or path == "/api/registrations":
        return None

    if path == "/api/user":
        if method == "GET":
            return None

        try:
            token = literal_eval(token) if token else None
            decoded = jwt.decode(token, key=_context.get_context("JWT_SECRET"))
            print("Decoded token: " + str(decoded))
        except Exception as e:
            print("authorize EXCEPTION:", str(e))
            return Response("Invalid login token or login required", status=412, content_type="text/plain")

        if method == "PUT":
            if decoded.get('email', None) != args.get("email"):
                return Response("No permission to modify other user", status=403, content_type="text/plain")
            else:
                return None
        if method == "DELETE":
            if decoded.get('role', None) != 'admin':
                return Response("Not admin, no permission to delete", status=403, content_type="text/plain")
            else:
                return None

    return None

# token = generate_token({"email":"dsad"})
# print(token)
# print(decode_token(token))