import copy

import os
import json


class Context():

    def __init__(self, inital_ctx=None):

        self._context = inital_ctx

    def get_context(self, ctx_name):

        result = self._context.get(ctx_name, None)
        return result

    def set_context(self, ctx_name, ctx):

        self._context[ctx_name] = copy.deepcopy(ctx)

    @classmethod
    def get_default_context(cls):

        db_connect_info = os.environ['db_connect_info']
        db_connect_info = json.loads(db_connect_info)

        ctx = {"db_connect_info": db_connect_info}
        ctx["JWT_SECRET"] = "cat"
        ctx['smarty_streets_id'] = os.environ.get('smarty_id')
        ctx['smarty_streets_token'] = os.environ.get('smarty_token')

        v_location = os.environ['address_validator_url']

        ctx['address_validator_url'] = v_location

        if v_location == "local":
            # The general best practice is to put imports at the beginning of a file and not
            # inside functions, classes, etc. In general, this is the best approach. I would not
            # use the approach here in practice.
            from Services.AddressValidation.ValidatorService import ValidatorService
            ctx["address_validator"] = ValidatorService
        else:
            from Services.AddressValidation.ValidatorClient import ValidatorClient
            ctx['address_validator'] = ValidatorClient

        result = Context(ctx)
        #result = ctx
        return result

