import DataAccess.DataAdaptor as data_adaptor
from abc import ABC, abstractmethod
import pymysql.err
import os
from Context.Context import Context


class DataException(Exception):

    unknown_error   =   1001
    duplicate_key   =   1002

    def __init__(self, code=unknown_error, msg="Something awful happened."):
        self.code = code
        self.msg = msg


class BaseDataObject(ABC):

    def __init__(self):
        pass

    @classmethod
    @abstractmethod
    def create_instance(cls, data):
        pass


class UsersRDB(BaseDataObject):

    def __init__(self, ctx):
        super().__init__()

        self._ctx = ctx

    @classmethod
    def get_by_email(cls, email, include_deleted=False):
        ctx = Context.get_default_context()
        c_info = ctx.get_context("db_connect_info")
        db = c_info["db"]
        sql = "select * from " + db + ".users where email=%s"
        if not include_deleted:
            sql = sql + " and status!='DELETED'"
        res, data = data_adaptor.run_q(sql=sql, args=[email], fetch=True)
        if data is not None and len(data) > 0:
            result = data[0]
        else:
            result = None

        return result

    @classmethod
    def get_by_id(cls, id, fields=None):
        ctx = Context.get_default_context()
        c_info = ctx.get_context("db_connect_info")
        db = c_info["db"]
        if not fields:
            sql = "select * from " + db + ".users where auto_id=%s"
        else:
            f = ', '.join(fields)
            sql = "select " + f + " from " + db + ".users where auto_id=%s"
        res, data = data_adaptor.run_q(sql=sql, args=[id], fetch=True)
        if data is not None and len(data) > 0:
            result = data[0]
        else:
            result = None
        return result

    # template of the form {col1: val1, col2: val2}
    @classmethod
    def get_by_columns(cls, template, fields):
        ctx = Context.get_default_context()
        c_info = ctx.get_context("db_connect_info")
        db = c_info["db"]
        try:
            sql, args = data_adaptor.create_select(table_name="users", template=template, fields=fields)
            res, data = data_adaptor.run_q(sql, args)
        except Exception as e:
            raise DataException()

        return data

    @classmethod
    def delete(cls, user_info):
        try:
            sql, args = data_adaptor.create_delete(table_name="users", email={"email": user_info["email"]})
            res, data = data_adaptor.run_q(sql, args)
        except pymysql.err.IntegrityError as ie:
            if ie.args[0] == 1062:
                raise (DataException(DataException.duplicate_key))
            else:
                raise DataException()
        except Exception as e:
            raise DataException()

        return res

    @classmethod
    def update(cls, user_info):
        try:
            sql, args = data_adaptor.create_update(table_name="users", new_values=user_info, template={"email": user_info["email"]})
            res, data = data_adaptor.run_q(sql, args)
        except pymysql.err.IntegrityError as ie:
            if ie.args[0] == 1062:
                raise (DataException(DataException.duplicate_key))
            else:
                raise DataException()
        except Exception as e:
            raise DataException()

        return res

    @classmethod
    def create_user(cls, user_info):

        result = None

        try:
            sql, args = data_adaptor.create_insert(table_name="users", row=user_info)
            res, data = data_adaptor.run_q(sql, args)
            if res != 1:
                result = None
            else:
                result = user_info['id']
        except pymysql.err.IntegrityError as ie:
            if ie.args[0] == 1062:
                raise (DataException(DataException.duplicate_key))
            else:
                raise DataException()
        except Exception as e:
            raise DataException()

        return result


class ProfileRDB(BaseDataObject):

    def __init__(self, ctx):
        super().__init__()

        self._ctx = ctx

    @classmethod
    def create_profile(cls, user_profile):
        try:
            sql, args = data_adaptor.create_insert(table_name="profile", row=user_profile)
            res, data = data_adaptor.run_q(sql, args)
            if res != 1:
                result = None
            else:
                result = user_profile['customer_id']
            return result
        except pymysql.err.IntegrityError as ie:
            if ie.args[0] == 1062:
                raise (DataException(DataException.duplicate_key))
            else:
                raise DataException()
        except Exception as e:
            raise DataException()



    @classmethod
    def get_profile(cls, template, fields):
        ctx = Context.get_default_context()
        c_info = ctx.get_context("db_connect_info")
        db = c_info["db"]
        try:
            sql, args = data_adaptor.create_select(table_name="profile", template=template, fields=fields)
            res, data = data_adaptor.run_q(sql, args)
            return data
        except Exception as e:
            raise DataException()



    @classmethod
    def get_from_id(cls, customer_id, fields=None):
        ctx = Context.get_default_context()
        c_info = ctx.get_context("db_connect_info")
        db = c_info["db"]
        if not fields:
            sql = "select * from " + db + ".profile where customer_id=%s"
        else:
            f = ', '.join(fields)
            sql = "select " + f + " from " + db + ".profile where customer_id=%s"
        res, data = data_adaptor.run_q(sql=sql, args=[customer_id], fetch=True)
        if data is not None and len(data) > 0:
            result = data
        else:
            result = None
        return result

    @classmethod
    def update_from_id(cls, customer_id, customer_profile):
        try:
            sql, args = data_adaptor.create_update(table_name="profile", new_values={"value":customer_profile["value"]},
                                                   template={"customer_id": customer_id, "type": customer_profile['type'],
                                                             "subtype": customer_profile['subtype']})
            res, data = data_adaptor.run_q(sql, args)
        except pymysql.err.IntegrityError as ie:
            if ie.args[0] == 1062:
                raise (DataException(DataException.duplicate_key))
            else:
                raise DataException()
        except Exception as e:
            raise DataException()

        return res

    @classmethod
    def delete_from_id(cls, customer_info):
        try:
            sql, args = data_adaptor.create_delete(table_name="profile", email={"customer_id": customer_info["customer_id"]})
            res, data = data_adaptor.run_q(sql, args)
        except pymysql.err.IntegrityError as ie:
            if ie.args[0] == 1062:
                raise (DataException(DataException.duplicate_key))
            else:
                raise DataException()
        except Exception as e:
            raise DataException()

        return res