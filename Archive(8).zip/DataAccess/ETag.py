import hashlib
import json


def getMD5(data: dict):
    string = json.dumps(data, sort_keys=True).encode("utf-8")
    data_md5 = hashlib.md5(string).hexdigest()
    return data_md5

# print(type(getMD5({3:4, 1:2})))
