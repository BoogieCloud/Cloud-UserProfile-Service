CREATE TABLE `address` (
  `address_id` varchar(45) NOT NULL,
  `primary_number` varchar(45) DEFAULT NULL,
  `street_name` varchar(45) DEFAULT NULL,
  `street_predirection` varchar(45) DEFAULT NULL,
  `street_postdirection` varchar(45) DEFAULT NULL,
  `street_suffix` varchar(45) DEFAULT NULL,
  `city_name` varchar(45) DEFAULT NULL,
  `default_city_name` varchar(45) DEFAULT NULL,
  `state_abbreviation` varchar(45) DEFAULT NULL,
  `plus4_code` varchar(45) DEFAULT NULL,
  `delivery_point` varchar(45) DEFAULT NULL,
  `delivery_point_check_digit` varchar(45) DEFAULT NULL,
  `zipcode` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
