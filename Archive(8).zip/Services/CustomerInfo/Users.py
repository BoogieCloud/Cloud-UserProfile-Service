from abc import ABC, abstractmethod
import json
from Context.Context import Context
from DataAccess.DataObject import UsersRDB as UsersRDB
from DataAccess.DataObject import ProfileRDB as ProfileRDB
from Middleware import notification
from Services.AddressValidation.ValidatorService import ValidatorService
import requests

# The base classes would not be IN the project. They would be in a separate included package.
# They would also do some things.


class ServiceException(Exception):

    unknown_error   =   9001
    missing_field   =   9002
    bad_data        =   9003

    def __init__(self, code=unknown_error, msg="Oh Dear!"):
        self.code = code
        self.msg = msg


class BaseService():

    missing_field   =   2001

    def __init__(self):
        pass


class UsersService(BaseService):
    required_create_fields = ['last_name', 'first_name', 'email', 'password']

    def __init__(self, ctx=None):

        if ctx is None:
            ctx = Context.get_default_context()

        self._ctx = ctx


    @classmethod
    def update(cls, user_info):

        result = UsersRDB.update(user_info)
        return result

    @classmethod
    def get_by_email(cls, email):

        result = UsersRDB.get_by_email(email)
        return result

    @classmethod
    def create_user(cls, user_info):

        for f in UsersService.required_create_fields:
            v = user_info.get(f, None)
            if v is None:
                raise ServiceException(ServiceException.missing_field,
                                       "Missing field = " + f)

            if f == 'email':
                if v.find('@') == -1:
                    raise ServiceException(ServiceException.bad_data,
                           "Email looks invalid: " + v)

        result = UsersRDB.create_user(user_info=user_info)
        # add logic here, every time create_user is called, a message will be published to
        # a topic on SNS

        # user_info is a dict, here we get email and publish it to SNS
        email = user_info.get("email", None)
        notification.publish_it(email)
        return result


class ProfileService(BaseService):

    def __init__(self, ctx=None):

        if ctx is None:
            ctx = Context.get_default_context()

        self._ctx = ctx

    @classmethod
    def create_profile(cls, profile_info):
        required_create_fields = ['customer_id', 'type', 'subtype', 'value']
        whole_type = ('Email', 'Address', 'Telephone', 'Other')
        whole_subtype = ('Work', 'Home', 'Mobile', 'Other')
        url = "https://t6eanqoqeh.execute-api.us-east-2.amazonaws.com/123/helloworld"

        for f in required_create_fields:
            v = profile_info.get(f, None)
            if v is None:
                raise ServiceException(ServiceException.missing_field,
                                       "Missing field = " + f)

            if f == 'type' and v not in whole_type:
                raise ServiceException(ServiceException.bad_data, "Bad data = " + f)

            if f == 'subtype' and v not in whole_subtype:
                raise ServiceException(ServiceException.bad_data, "Bad data = " + f)

            if v == 'Address':
                address = profile_info.get('value', None)
                if address is None:
                    raise ServiceException(ServiceException.missing_field,
                                           "Missing field = value")
                else:
                    t_answer = requests.post(url, data=address)
                    t_answer = json.loads(t_answer.text)
                    #v_service = ValidatorService(Context.get_default_context())
                    #t_answer = v_service.validate_address(address)

                    if t_answer is None:
                        raise ServiceException(ServiceException.bad_data, "Invalid address information = " + v)
                    else:
                        address_id = t_answer['address_id']
                        profile_info['value'] = address_id

        result = ProfileRDB.create_profile(profile_info)
        return result

    @classmethod
    def get_profile(cls, template, fields=None):
        url = "https://t6eanqoqeh.execute-api.us-east-2.amazonaws.com/123/helloworld"
        result = ProfileRDB.get_profile(template, fields)
        if result[0]['type'] == 'Address':
            address = requests.get(url, params={"address_id": result[0]['value']})
            address = json.loads(address.text)
            result[0]['value'] = address
        return result

    @classmethod
    def get_from_id(cls, customer_id, fields=None):
        url = "https://t6eanqoqeh.execute-api.us-east-2.amazonaws.com/123/helloworld"
        result = ProfileRDB.get_from_id(customer_id, fields)
        for i in range(len(result)):
            if result[i]['type'] == 'Address':
                address = requests.get(url, params={"address_id": result[i]['value']})
                address = json.loads(address.text)
                result[i]['value'] = address
        return result

    @classmethod
    def update_from_id(cls, customer_id, customer_info):

        if customer_info.get('type') == 'Address':
            url = "https://t6eanqoqeh.execute-api.us-east-2.amazonaws.com/123/helloworld"
            address = customer_info.get('value')
            if address is None:
                raise ServiceException(ServiceException.missing_field,
                                       "Missing field = value")
            else:
                t_answer = requests.post(url, data=address)
                t_answer = json.loads(t_answer.text)
                #v_service = ValidatorService(Context.get_default_context())
                #t_answer = v_service.validate_address(address)

                if t_answer is None:
                    raise ServiceException(ServiceException.bad_data, "Invalid address information")
                else:
                    address_id = t_answer['address_id']
                    customer_info['value'] = address_id
        if customer_info.get('type') is None:
            raise ServiceException(ServiceException.missing_field,
                                   "Missing field = type")
        if customer_info.get('subtype') is None:
            raise ServiceException(ServiceException.missing_field,
                                   "Missing field = subtype")
        if customer_info.get('value') is None:
            raise ServiceException(ServiceException.missing_field,
                                   "Missing field = value")
        result = ProfileRDB.update_from_id(customer_id, customer_info)
        return result

    @classmethod
    def delete_from_id(cls, customer_info):
        result = ProfileRDB.delete_from_id(customer_info)
        return result




