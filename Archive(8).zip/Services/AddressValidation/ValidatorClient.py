from Services.AddressValidation.Validator import Validator

import requests


class ValidatorClient(Validator):

    def __init__(self, context):
        self._context = context

    def validate_address(self, address):
        base_url = self._context['address_validator_url']
        url = base_url + "/addresses"
        #url = base_url
        args = {}

        city = address.get('city', None)
        if city is not None:
            args['city'] = city

        state = address.get('state', None)
        if state is not None:
            args['state'] = state

        street = address.get('street', None)
        if street is not None:
            args['street'] = street

        zipcode = address.get('zipcode', None)
        if zipcode is not None:
            args['zipcode'] = street

        result = requests.get(url=url, params=args)
        if result.status_code == 200:
            # If we got more than one address, then there was something wrong and the address into is imprecise
            j_data = result.json()

            if len(j_data) > 1:
                rsp = None
            else:
                rsp = j_data[0]['components']
                rsp['deliver_point_barcode'] = j_data[0]['delivery_point_barcode']
        else:
            rsp = None

        return rsp

    def get_zip_code(self, town_info):
        base_url = self._context['address_validator_url']
        #url = base_url
        url = base_url + "/zipcodes"
        args = {"city": town_info["city"], "state": town_info["state"]}
        result = requests.get(url=url, params=args)
        result = result.json()
        result = result[0]

        return result




